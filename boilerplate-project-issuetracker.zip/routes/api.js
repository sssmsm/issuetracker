'use strict';
require('dotenv').config();
//const { MongoClient } = require('mongodb');
const mongoose = require('mongoose');
const URI = process.env.MONGO_URI;

module.exports = function (app) {

  //const client = new MongoClient(URI, { useNewUrlParser: true, useUnifiedTopology: true });
  //client.connect();
  mongoose.connect(URI, { useNewUrlParser: true, useUnifiedTopology: true });

  const issueSchema = new mongoose.Schema({
    issue_title: String,
    issue_text: String,
    created_by: String,
    assigned_to: String,
    status_text: String,
    open: Boolean,
    created_on: Date,
    updated_on: Date,
    project: String
  });

  const Issue = mongoose.model('Issue', issueSchema);

  app.route('/api/issues/:project')
  
    .get(function (req, res){
      let project = req.params.project;
      let filter = Object.assign(req.query, {project: project})
      //console.log(filter);
      Issue.find(filter).exec((err, issues) => {
        if (err) { return console.log(err) };
        res.send(issues);        
      })
      // MyModel.find({ name: 'john', age: { $gte: 18 }}, function (err, docs) {});
    })
    
    .post(function (req, res){
      let project = req.params.project;

      if (!req.body.issue_title || !req.body.issue_text || !req.body.created_by) {
        return res.json({ error: 'required field(s) missing' });
      }

      let newIssue = new Issue({
        issue_title: req.body.issue_title,
        issue_text: req.body.issue_text,
        created_by: req.body.created_by,
        assigned_to: req.body.assigned_to || '',
        status_text: req.body.status_text || '',
        open: true,
        created_on: new Date().toUTCString(),
        updated_on: new Date().toUTCString(),
        project: project
      })

      newIssue.save((err, issue) => {
        if (err) { return console.log(err) };
        if (issue) {
          //console.log(issue);
          return res.json(issue);
        }
      });
    })
    
    .put(function (req, res){
      let project = req.params.project;
      
      if (!req.body._id) { return res.json({ error: 'missing _id' }) };
      if (Object.keys(req.body).length < 2) { return res.json({ error: 'no update field(s) sent', '_id': req.body._id}) };

      let updates = {};
      Object.keys(req.body).forEach(key => {
        if (req.body[key] != '') {
          updates[key] = req.body[key];
        }
      });

      updates['updated_on'] = new Date().toUTCString();
      //console.log(updates);
      // Model.findByIdAndUpdate(id, { name: 'jason bourne' }, options, callback)
      Issue.findByIdAndUpdate(req.body._id, updates, (err, issue) => {
        //console.log("issue: " + issue);
        if (!issue || err) { return res.json({ error: 'could not update', '_id': req.body._id }) };
        if (issue) {
          //console.log(issue);
          return res.json({ result: 'successfully updated', '_id': req.body._id })
        }
      })
    })
    
    .delete(function (req, res){
      let project = req.params.project;

      if (!req.body._id) { return res.json({ error: 'missing _id' }) };

      Issue.findByIdAndDelete(req.body._id, (err, issue) => {
        if (!issue || err) { return res.json({error: 'could not delete', '_id': req.body._id}) };
        if (issue) {
          //console.log(issue);
          return res.json({ result: 'successfully deleted', '_id': req.body._id });
        }
      });

    });
    
};
