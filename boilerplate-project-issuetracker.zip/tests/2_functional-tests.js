const chaiHttp = require('chai-http');
const chai = require('chai');
const assert = chai.assert;
const server = require('../server');

chai.use(chaiHttp);

suite('Functional Tests', function() {

let issueId

//Create an issue with every field: POST request to /api/issues/{project}
test('every field', (done) => {
  chai
  .request(server)
  .post('/api/issues/fcc')
  .send({
    issue_title: 'fcc1',
    issue_text: 'fcc2',
    created_by: 'fcc3',
    assigned_to: 'fcc4',
    status_text: 'fcc5',
  })
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.issue_title, 'fcc1');
    assert.equal(res.body.issue_text, 'fcc2');
    assert.equal(res.body.created_by, 'fcc3');
    assert.equal(res.body.assigned_to, 'fcc4');
    assert.equal(res.body.status_text, 'fcc5');
    issueId = res.body._id;
  });
  done();
});

//Create an issue with only required fields: POST request to /api/issues/{project}
test('required fields', (done) => {
  chai
  .request(server)
  .post('/api/issues/fcc')
  .send({
    issue_title: 'fcc1',
    issue_text: 'fcc2',
    created_by: 'fcc3'
  })
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.issue_title, 'fcc1');
    assert.equal(res.body.issue_text, 'fcc2');
    assert.equal(res.body.created_by, 'fcc3');
  });
  done();
});

//Create an issue with missing required fields: POST request to /api/issues/{project}
test('missing required fields', (done) => {
  chai
  .request(server)
  .post('/api/issues/fcc')
  .send({
    issue_text: 'fcc2',
    created_by: 'fcc3',
    assigned_to: 'fcc4',
    status_text: 'fcc5',
  })
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.error, 'required field(s) missing');
  });
  done();
});

//View issues on a project: GET request to /api/issues/{project}
test('view issues', (done) => {
  chai
  .request(server)
  .get('/api/issues/fcc')
  .query({})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.isArray(res.body);
  });
  done();
});

//View issues on a project with one filter: GET request to /api/issues/{project}
test('one filter', (done) => {
  chai
  .request(server)
  .get('/api/issues/fcc')
  .query({issue_title: 'fcc1'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body[0].issue_title, 'fcc1');
  });
  done();
});

//View issues on a project with multiple filters: GET request to /api/issues/{project}
test('multiple filters', (done) => {
  chai
  .request(server)
  .get('/api/issues/fcc')
  .query({
    issue_title: 'fcc1',
    issue_text: 'fcc2'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body[0].issue_title, 'fcc1');
    assert.equal(res.body[0].issue_text, 'fcc2');
  });
  done();
});

//Update one field on an issue: PUT request to /api/issues/{project}
test('update one field', (done) => {
  chai
  .request(server)
  .put('/api/issues/fcc')
  .send({
    _id: issueId,
    issue_title: 'fcc10'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.result, 'successfully updated');
  });
  done();
});

//Update multiple fields on an issue: PUT request to /api/issues/{project}
test('update multiple fields', (done) => {
  chai
  .request(server)
  .put('/api/issues/fcc')
  .send({
    _id: issueId,
    issue_title: 'fcc11',
    issue_text: 'fcc12'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.result, 'successfully updated');
  });
  done();
});

//Update an issue with missing _id: PUT request to /api/issues/{project}
test('missing id', (done) => {
  chai
  .request(server)
  .put('/api/issues/fcc')
  .send({
    issue_title: 'fcc13'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.error, 'missing _id');
  });
  done();
});

//Update an issue with no fields to update: PUT request to /api/issues/{project}
test('no fields to update', (done) => {
  chai
  .request(server)
  .put('/api/issues/fcc')
  .send({
    _id: issueId})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.error, 'no update field(s) sent');
  });
  done();
});

//Update an issue with an invalid _id: PUT request to /api/issues/{project}
test('invalid id', (done) => {
  chai
  .request(server)
  .put('/api/issues/fcc')
  .send({
    _id: 1313,
    issue_title: 'fcc14'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.error, 'could not update');
  });
  done();
});

//Delete an issue: DELETE request to /api/issues/{project}
test('delete issue', (done) => {
  chai
  .request(server)
  .delete('/api/issues/fcc')
  .send({
    _id: issueId})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.result, 'successfully deleted');
  });
  done();
});

//Delete an issue with an invalid _id: DELETE request to /api/issues/{project}
test('delete invalid id', (done) => {
  chai
  .request(server)
  .delete('/api/issues/fcc')
  .send({
    _id: 1313})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.error, 'could not delete');
  });
  done();
});

//Delete an issue with missing _id: DELETE request to /api/issues/{project}
test('delete MISSING id', (done) => {
  chai
  .request(server)
  .delete('/api/issues/fcc')
  .send({
    issue_title: 'fcc1'})
  .end((err, res) => {
    assert.equal(res.status, 200);
    assert.equal(res.body.error, 'missing _id');
  });
  done();
});

  
});
